sudo apt install cppcheck
sudo apt install clang-tidy

