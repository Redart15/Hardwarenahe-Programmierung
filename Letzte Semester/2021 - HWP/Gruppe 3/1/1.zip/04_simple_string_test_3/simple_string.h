/* Soll die Anzahl an Zeichen in einem String zählen. */
int zeichen_zaehlen(char zeichen[]);

/* Soll string2 an string1 anhängen. */
void string_anhaengen(char string1[], char string2[]);
