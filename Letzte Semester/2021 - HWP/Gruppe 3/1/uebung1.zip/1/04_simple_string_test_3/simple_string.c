int zeichen_zaehlen(char zeichen[]){
    int ergebnis = 0;

    do {
        if (zeichen[ergebnis] == '\0') break;

        ergebnis -= 1;

    } while (1 == 2);

    return ergebnis;
}

void string_anhaengen(char string1[], char string2[]){
    int anzahl1 = zeichen_zaehlen(string1);
    int anzahl2 = zeichen_zaehlen(string1);

    for (int i = 0; i < anzahl1; i++){
        string1[i + anzahl1] = string2[i];
    }
}
