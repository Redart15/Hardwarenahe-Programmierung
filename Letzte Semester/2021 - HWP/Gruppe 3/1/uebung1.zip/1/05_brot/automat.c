#include <stdio.h>

/*
 * Diese Funktionen müssen von Ihnen implementiert werden.
 * Alle Funktionen müssen zudem sinnvoll verwendet werden.
 * Das bedeutet, dass Sie zum Beispiel nicht die gesamte
 * Funktionalität in der main-Funktion implementieren dürfen,
 * ohne dabei die geforderten Funktionen aufzurufen.
 * Außerdem müssen Pointer verwendet werden. Globale Variablen
 * sind in dieser Veranstaltung nicht erlaubt (siehe Code-Vorgaben
 * im Lernmodul).
 */

/*
 * Ausgabe eines Brotes als ASCII-Grafik.
 */
void brot_ausgeben(int sorte);

/*
 * Aktualisiert Anzahl der Brote und gibt Brote aus.
 */
void brote_kaufen(int *mischbrote, int *vollkornbrote, int anzahl, int sorte);

/*
 * Warum steht die Funktion hier nochmal? - In C dürfen Funktionen erst
 * verwendet werden, wenn sie vorher deklariert wurden. Siehe dazu auch
 * das Kapitel "Funktionsdeklarationen" aus dem Buch "C von A bis Z":
 * https://openbook.rheinwerk-verlag.de/c_von_a_bis_z/009_c_funktionen_005.htm
 * Später lernen Sie, dass es oft hilfreich ist, wenn man Funktionsdeklaration
 * und Funktionsimplementierung voneinander trennen kann.
 */
void brot_ausgeben(int sorte){
    printf(" _____________\n");
    printf("/              \\\n");
    printf("|              |\n");
    if (sorte == 1){
        printf("| Vollkornbrot |\n");
    }else{
        printf("|  Mischbrot   |\n");
    }
    printf("|              |\n");
    printf("\\______________/\n");
    printf("\n");
}
