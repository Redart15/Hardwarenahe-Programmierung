int berechnung3(int x);
