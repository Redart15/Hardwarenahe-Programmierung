gcc -g -fsanitize=address -fsanitize=undefined -Wall -std=c99 mathematik.c berechnung1.c berechnung2.c berechnung3.c berechnung.c -o berechnung
