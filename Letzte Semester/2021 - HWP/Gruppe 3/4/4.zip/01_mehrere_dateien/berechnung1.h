int berechnung1(int x, int y);
