int berechnung2(int x, int y, int z);
