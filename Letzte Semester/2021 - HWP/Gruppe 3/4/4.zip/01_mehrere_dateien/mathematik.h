int quadrat(int x);
int anzahl_bits(int x);
int wurzel(int x);
