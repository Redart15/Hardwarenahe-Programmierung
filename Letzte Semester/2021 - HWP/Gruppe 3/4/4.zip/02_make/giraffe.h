void giraffe(void);
