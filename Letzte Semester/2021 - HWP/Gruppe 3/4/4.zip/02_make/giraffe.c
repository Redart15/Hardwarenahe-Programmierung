#include "giraffe.h"
#include <stdio.h>

void giraffe(void){
    printf("Hier ist eine Giraffe.\n");
}
