#include "zoo.h"

int main(){

    zoo();

    return 0;
}
