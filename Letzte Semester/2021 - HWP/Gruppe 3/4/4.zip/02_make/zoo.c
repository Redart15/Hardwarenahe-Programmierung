#include "zoo.h"
#include "elefant.h"
#include "giraffe.h"

void zoo(void){
    elefant();

    giraffe();
}
