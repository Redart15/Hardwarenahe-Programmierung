void zoo(void);

//zoo.h wurde durch diesen Kommentar verändert.
//zoo.h wurde durch diesen Kommentar verändert.
//zoo.h wurde durch diesen Kommentar verändert.
//zoo.h wurde durch diesen Kommentar verändert.
//zoo.h wurde durch diesen Kommentar verändert.
