void elefant(void);
