/*
 * Sucht einen String in einem Text und gibt die erste gefundene Position zurück.
 * Wenn nichts gefunden wird, dann wird -1 zurückgegeben.
 */
int string_suchen(char *text, char *string);
