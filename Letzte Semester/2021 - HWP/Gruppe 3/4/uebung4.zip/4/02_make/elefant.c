#include "elefant.h"
#include <stdio.h>

void elefant(void){
    printf("Hier trompetet ein Elefant.\n");
}
