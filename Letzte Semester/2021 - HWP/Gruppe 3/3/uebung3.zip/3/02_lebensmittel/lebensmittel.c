/* Implementieren Sie hier wenn nötig noch weitere Funktionen */

int main(int argc, char* argv[]){
    /* Diese Funktion muss implementiert werden. */

    return 0;
}

