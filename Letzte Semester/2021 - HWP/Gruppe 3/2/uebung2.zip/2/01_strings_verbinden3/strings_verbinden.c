/*
 * Implementieren Sie hier ihre Lösung.
 */
