/*
 * Diese Funktion soll die Strings str1, str2 und str3 hintereinander
 * in "zusammen" schreiben.
 * Achten Sie wie immer darauf, ihre Strings zu terminieren!
 * Suchen Sie sich eine der folgenden Funktionssignaturen aus.
 */

Suchen Sie sich eine der folgenden Funktionssignaturen aus,
indem Sie sie auskommentieren. Die Tests (ts-Datei) inkludieren diese
Header-Datei und können dadurch dann die Funktion strings_verbinden verwenden.

Diese Nachricht verursacht absichtlich einen Fehler beim kompilieren,
damit Sie in diese Datei hier schauen, was anscheinend funktioniert hat.
Diese Nachricht darf nun gelöscht werden.

//void strings_verbinden(char zusammen[], char str1[], char str2[], char str3[]);
//void strings_verbinden(char *zusammen, char *str1, char *str2, char *str3);
