/*
 * Konvertiert einen String zu snake_case.
 */
void zu_snake_case(char *string);

