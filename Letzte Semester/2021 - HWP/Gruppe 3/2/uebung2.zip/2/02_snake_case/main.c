#include "snake_case.h"
#include <stdio.h>

int main() {
    char string[2000];
    printf("Geben Sie einen String ein:\n");
    if (fgets(string, sizeof(string)/2, stdin)){
        zu_snake_case(string);

        printf("\nZu snake_case konvertiert:\n");

        printf("%s", string);
    }

    return 0;
}
