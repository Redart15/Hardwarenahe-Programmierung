/*
 * Implementieren Sie hier die geforderte Funktion.
 */
