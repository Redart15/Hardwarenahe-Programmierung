#include <stdio.h>
#include <string.h>

/*
 * Sucht urls in String "text", schreibt diese in das Array "urls" und
 * gibt die Anzahl an gefundenen URLs zurück.
 */
int urls_finden(char urls[10][150], char *text);
