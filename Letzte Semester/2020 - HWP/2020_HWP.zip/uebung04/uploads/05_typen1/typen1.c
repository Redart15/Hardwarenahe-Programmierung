#include <stdio.h>

int main( int argc, char ** argv ){
    if(argc <= 1){
        printf("Usage:  fassungsvermoegen <zahl>\n");
        return 1;
    }
    
    TODO

    printf("  char      : TODO\n", 42 );
    printf("  int       : TODO\n", 42 );
    printf("  double    : TODO\n", 42 );
    
    return 0;
}
