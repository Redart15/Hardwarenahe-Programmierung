
double dividiere(int a, int b);
