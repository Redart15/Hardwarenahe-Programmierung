// Diese Funktion soll die Zahl 'a' durch die Zahl 'b' ohne runden teilen.
double dividiere(int a, int b)
{
  return (double)a / (double)b;
}

/*
  int a = 3;
  int b = 2;
  double x = a / b; ergibt 1.000000 beim printen
*/