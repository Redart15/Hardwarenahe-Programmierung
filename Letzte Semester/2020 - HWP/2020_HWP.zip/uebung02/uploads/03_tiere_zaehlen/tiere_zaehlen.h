#include <stdio.h>
#include <string.h>
#include <stdlib.h>

/* Implementieren Sie diese Funktion. */
int tiere_zaehlen(char tiere[10][16], char *string);
