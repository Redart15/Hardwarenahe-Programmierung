
void caesar(char *klartext);

int encode_and_compare(char *encoded_string, char *string_to_encode);
