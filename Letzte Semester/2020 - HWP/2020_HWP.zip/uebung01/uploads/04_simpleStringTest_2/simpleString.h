
/*
 * Soll 1 zurückgeben, wenn die beiden übergebenen Strings gleich sind, 0 sonst.
 */
int my_strcmp(char *string1, char *string2);

/*
 * Soll zurückgeben, wie oft das Zeichen "needle" im String "haystack" vorkommt.
 */
int count_in_string(char *haystack, char needle);

